package ESMS;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Cust_account {
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lbluser_id,lblusername,lblpno,lblemail,lbladd,lblpwd;
	private JTextField txtuser_id,txtusername,txtpno,txtemail,txtpwd;
	private JTextArea txtadd;
	private List userIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Cust_account(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lbluser_id=new JLabel("Cust_ID");
		lblusername=new JLabel("Customer Name");
		lblpno=new JLabel("Phone Number");
		lblemail=new JLabel("Email");
		lbladd=new JLabel("Address");
		lblpwd=new JLabel("Password");
		
		txtuser_id=new JTextField(15);
		txtusername=new JTextField(15);
		txtpno=new JTextField(15);
		txtemail=new JTextField(30);
		txtadd=new JTextArea(15,15);
		txtpwd=new JPasswordField(8);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737096","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loaduserIDs() {
		try {
			userIDList.removeAll();
			rs=statement.executeQuery("select cust_id from cust_account");
			while(rs.next()) {
				userIDList.add(rs.getString("cust_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
				
				 lbluser_id.setForeground(Color.WHITE);
				 lblusername.setForeground(Color.WHITE);
				 lblpwd.setForeground(Color.WHITE);
			     lblpno.setForeground(Color.WHITE);
			     lblemail.setForeground(Color.WHITE);
				 lbladd.setForeground(Color.WHITE);
			    
				 p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.RED);
				 p3.setBounds(320,370,75,35);
					 
				 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);
				 p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO cust_account VALUES("+txtuser_id.getText()+",'"+txtusername.getText()+"',"+txtpno.getText()+",'"+txtemail.getText()+"','"+txtadd.getText()+"','"+txtpwd.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loaduserIDs();
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				lbluser_id.setForeground(Color.WHITE);
				 lblusername.setForeground(Color.WHITE);
				 lblpwd.setForeground(Color.WHITE);
			     lblpno.setForeground(Color.WHITE);
			     lblemail.setForeground(Color.WHITE);
				 lbladd.setForeground(Color.WHITE);
				
				p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 //p1.add(deleteButton);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.RED);
					p3.setBounds(320,370,75,35);
					 
					 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 userIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from cust_account");
								while (rs.next()) 
								{
									if (rs.getString("cust_id").equals(userIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("cust_id"));
									txtusername.setText(rs.getString("cust_name"));
									txtpno.setText(rs.getString("ph_no"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
									txtpwd.setText(rs.getString("password"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM cust_account WHERE cust_id="+txtuser_id.getText();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loaduserIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				
				txtuser_id.setText(null);
				txtusername.setText(null);
				txtpwd.setText(null);
				txtpno.setText(null);
				txtemail.setText(null);
				txtadd.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				lbluser_id.setForeground(Color.WHITE);
				 lblusername.setForeground(Color.WHITE);
			     lblpno.setForeground(Color.WHITE);
			     lblemail.setForeground(Color.WHITE);
				 lbladd.setForeground(Color.WHITE);
				 lblpwd.setForeground(Color.WHITE);
				
				p1.setLayout(new GridLayout(6,7));
				 p1.add(lbluser_id);
				 p1.add(txtuser_id);
				 p1.add(lblusername);
				 p1.add(txtusername);
				 p1.add(lblpwd);
				 p1.add(txtpwd);
				 p1.add(lblpno);
				 p1.add(txtpno);
				 p1.add(lblemail);
				 p1.add(txtemail);
				 p1.add(lbladd);
				 p1.add(txtadd);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.RED);
					p3.setBounds(320,370,75,35);
					 
					 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 userIDList=new List(10);
				 loaduserIDs();
				 p2.add(userIDList);
				 p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 userIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from cust_account");
								while (rs.next()) 
								{
									if (rs.getString("cust_id").equals(userIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtuser_id.setText(rs.getString("cust_ID"));
									txtusername.setText(rs.getString("cust_name"));
									txtpno.setText(rs.getString("ph_no"));
									txtemail.setText(rs.getString("email"));
									txtadd.setText(rs.getString("address"));
									txtpwd.setText(rs.getString("password"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update cust_account set cust_name='"+txtusername.getText()+"',ph_no="+txtpno.getText()+",email='"+txtemail.getText()+"',address='"+txtadd.getText()+"',password='"+txtpwd.getText()+"' WHERE cust_id="+txtuser_id.getText();
					
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loaduserIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("View Customer Accounts");
				Font myFont = new Font("Serif",Font.BOLD,30);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				p2=new JPanel(new FlowLayout());
				p2.add(viewButton);
				p1.setBackground(Color.PINK) ;
				p2.setBackground(Color.RED) ;
				p2.setBounds(320,120,80,35);
				p1.setBounds(220,15,350,100);
				p.add(p1);
				p.add(p2);
				p.setLayout(new BorderLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Customer Account details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("Cust_id");
						       model.addColumn("Customer name");
						       model.addColumn("Password");
						       model.addColumn("Phone Number");
						       model.addColumn("E-Mail");
						       model.addColumn("Address");
						      
						       try {
									
									rs=statement.executeQuery("select * from cust_account");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("cust_id"), rs.getString("cust_name"),rs.getString("password"),rs.getString("ph_no"),rs.getString("email"),rs.getString("address"),});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


