
package ESMS;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Product {
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblpid,lblpname,lblprice,lbltype,lblinstock;
	private JTextField txtpid,txtpname,txtprice,txttype,txtinstock;
	private List ProductIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Product(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblpid=new JLabel("Product ID");
		lblpname=new JLabel("Product Name");
		lblprice=new JLabel("Price");
		lbltype=new JLabel("Type");
		lblinstock=new JLabel("In Stock");
		
		txtpid=new JTextField(15);
		txtpname=new JTextField(15);
		txtprice=new JTextField(15);
		txttype=new JTextField(30);
		txtinstock=new JTextField(30);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737096","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadproductIDs() {
		try {
			ProductIDList.removeAll();
			rs=statement.executeQuery("select pid from product");
			while(rs.next()) {
				ProductIDList.add(rs.getString("pid"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("Submit");
				txtpid.setText(null);
				txtpname.setText(null);
				txtprice.setText(null);
				txttype.setText(null);
				txtinstock.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
				
				 lblpid.setForeground(Color.WHITE);
				 lblpname.setForeground(Color.WHITE);
			     lblprice.setForeground(Color.WHITE);
			     lbltype.setForeground(Color.WHITE);
				 lblinstock.setForeground(Color.WHITE);
			    
				 p1.setLayout(new GridLayout(5,7));
				 p1.add(lblpid);
				 p1.add(txtpid);
				 p1.add(lblpname);
				 p1.add(txtpname);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lbltype);
				 p1.add(txttype);
				 p1.add(lblinstock);
				 p1.add(txtinstock);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 p3.setBackground(Color.RED);
				 p3.setBounds(320,370,75,35);
					 
				 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 ProductIDList=new List(10);
				 loadproductIDs();
				 p2.add(ProductIDList);
				 p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 
					
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO product VALUES("+txtpid.getText()+",'"+txtpname.getText()+"',"+txtprice.getText()+",'"+txttype.getText()+"','"+txtinstock.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loadproductIDs();
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("Delete");
				
				txtpid.setText(null);
				txtpname.setText(null);
				txtprice.setText(null);
				txttype.setText(null);
				txtinstock.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				lblpid.setForeground(Color.WHITE);
				 lblpname.setForeground(Color.WHITE);
			     lblprice.setForeground(Color.WHITE);
			     lbltype.setForeground(Color.WHITE);
				 lblinstock.setForeground(Color.WHITE);
			    
				 p1.setLayout(new GridLayout(5,7));
				 p1.add(lblpid);
				 p1.add(txtpid);
				 p1.add(lblpname);
				 p1.add(txtpname);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lbltype);
				 p1.add(txttype);
				 p1.add(lblinstock);
				 p1.add(txtinstock);
				 //p1.add(deleteButton);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.RED);
					p3.setBounds(320,370,75,35);
					 
					 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 ProductIDList=new List(10);
				 loadproductIDs();
				 p2.add(ProductIDList);
				 p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 ProductIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from product");
								while (rs.next()) 
								{
									if (rs.getString("pid").equals(ProductIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtpid.setText(rs.getString("pID"));
									txtpname.setText(rs.getString("pname"));
									txtprice.setText(rs.getString("price"));
									txttype.setText(rs.getString("type"));
									txtinstock.setText(rs.getString("in_stock"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM product WHERE pid="+txtpid.getText();
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadproductIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("Modify");
				
				txtpid.setText(null);
				txtpname.setText(null);
				txtprice.setText(null);
				txttype.setText(null);
				txtinstock.setText(null);
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				p1=new JPanel();
				lblpid.setForeground(Color.WHITE);
				 lblpname.setForeground(Color.WHITE);
			     lblprice.setForeground(Color.WHITE);
			     lbltype.setForeground(Color.WHITE);
				 lblinstock.setForeground(Color.WHITE);
			    
				 p1.setLayout(new GridLayout(5,7));
				 p1.add(lblpid);
				 p1.add(txtpid);
				 p1.add(lblpname);
				 p1.add(txtpname);
				 p1.add(lblprice);
				 p1.add(txtprice);
				 p1.add(lbltype);
				 p1.add(txttype);
				 p1.add(lblinstock);
				 p1.add(txtinstock);
				 p1.setBackground(Color.GRAY) ;
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.RED);
					p3.setBounds(320,370,75,35);
					 
					 p1.setBounds(200,80,300,250);
				
				 p2 = new JPanel(new FlowLayout());
				
				 ProductIDList=new List(10);
				 loadproductIDs();
				 p2.add(ProductIDList);
				 p2.setBackground(Color.PINK) ;
				 
				 p2.setBounds(210,430,300,180);  
				 
				 
				 p. add(p1);
				 
				 p.add(p3);   
		
				 p. add(p2);
				 ProductIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from product");
								while (rs.next()) 
								{
									if (rs.getString("pid").equals(ProductIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtpid.setText(rs.getString("pID"));
									txtpname.setText(rs.getString("pname"));
									txtprice.setText(rs.getString("price"));
									txttype.setText(rs.getString("type"));
									txtinstock.setText(rs.getString("in_stock"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								if(a==JOptionPane.YES_OPTION){  
								String query="update product set pname='"+txtpname.getText()+"',price="+txtprice.getText()+",type='"+txttype.getText()+"',in_stock='"+txtinstock.getText()+"' WHERE pid="+txtpid.getText();
					
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadproductIDs();
								}
								
								
							}
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("View Products");
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p1.add(view1);
				p2=new JPanel(new FlowLayout());
				p2.add(viewButton);
				p1.setBackground(Color.PINK) ;
				p2.setBackground(Color.RED) ;
				p2.setBounds(340,120,80,35);
				p1.setBounds(220,15,350,100);
				p.add(p1);
				p.add(p2);
				p.setLayout(new BorderLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Customer Account details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn(" Product id");
						       model.addColumn("Product name");
						       model.addColumn("Price");
						       model.addColumn("Type");
						       model.addColumn("In-stock");
						      
						       try {
									
									rs=statement.executeQuery("select * from product");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("pid"), rs.getString("pname"),rs.getString("price"),rs.getString("type"),rs.getString("in_stock"),});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


