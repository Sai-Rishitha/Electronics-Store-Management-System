package ESMS;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class User_Details {

	private JPanel p1,p2,p3,p;
	private JLabel l1,l2,l3,l4,l5;
	private JTextField t1,t2,t3,t4,t5;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	String s;
	JMenu m1;
	private JMenuItem item1;
	
	public User_Details(JPanel p,JFrame frame,String s,JMenuItem item1)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.p=p;
		this.s=s;
		this.item1=item1;
		l1=new JLabel("Customer ID");
		l1.setFont(new Font("Verdana", Font.PLAIN, 20));
		l1.setBounds(193, 102, 438, 24);
		l2=new JLabel("Customer Name");
		l2.setFont(new Font("Verdana", Font.PLAIN, 20));
		l2.setBounds(183, 169, 176, 24);
		l3=new JLabel("Phone Number");
		l3.setFont(new Font("Verdana", Font.PLAIN, 20));
		l3.setBounds(183, 234, 161, 24);
		l4=new JLabel("E-Mail");
		l4.setFont(new Font("Verdana", Font.PLAIN, 20));
		l4.setBounds(222, 297, 77, 24);
		l5=new JLabel("Address");
		l5.setFont(new Font("Verdana", Font.PLAIN, 20));
		l5.setBounds(217, 356, 95, 24);
		t1=new JTextField(15);
		t1.setBounds(465, 104, 151, 24);
		
		t2=new JTextField(15);
		t2.setBounds(465, 176, 151, 24);
		t3=new JTextField(15);
		t3.setBounds(465, 234, 151, 24);
		t4=new JTextField(15);
		t4.setBounds(465, 297, 151, 24);
		t5=new JTextField(15);
		t5.setBounds(465, 356, 151, 24);
	}


public void connectToDB() 
{
	try {
	  
	
	Connection con=DriverManager.getConnection(  
	"jdbc:oracle:thin:@localhost:1521:xe","it19737096","vasavi");  
	  
	 
	statement=con.createStatement(); 
	statement.executeUpdate("commit");
	
	
	}
	catch (SQLException connectException) 
	{
	  System.out.println(connectException.getMessage());
	  System.out.println(connectException.getSQLState());
	  System.out.println(connectException.getErrorCode());
	  System.exit(1);
	}
}
private void displaySQLErrors(SQLException e) 
{
	JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	
	
}
public void buildGUI() {
	item1.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			t1.setText(null);
			t2.setText(null);
			t3.setText(null);
			t4.setText(null);
			t5.setText(null);
			
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			 p1=new JPanel();
			 p1.setLayout(null);
			 p1.add(l1);
			 p1.add(t1);
			 p1.add(l2);
			 p1.add(t2);
			 p1.add(l3);
			 p1.add(t3);
			 p1.add(l4);
			 p1.add(t4);
			 p1.add(l5);
			 p1.add(t5);
			 System.out.println(s);
			 p1.setBackground(new Color(255, 182, 193)) ;
			 p1.setBounds(20,20,700,700);
			 p.add(p1);
			
			 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 String query = "select cust_name,ph_no,email,address from cust_account where cust_id="+s;
				 try  {
				       rs = statement.executeQuery(query);
				      while (rs.next()) {
				        String name = rs.getString("cust_NAME");
				        String pno = rs.getString("ph_no");
				        String mail = rs.getString("email");
				        String add= rs.getString("address");
				       // System.out.println(name + ", " + pno + ", " + mail+
				                          // ", " + add);
	
	                t2.setText(name);
	                t2.setEditable(false);
	                t3.setText(pno);
	                t3.setEditable(false);
	                t4.setText(mail);
	                t4.setEditable(false);
	                t5.setText(add);
	                t5.setEditable(false);
	                
				      }
				    } catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				 t1.setText(s);
				 t1.setEditable(false);
				 
				 
		}
	});
}}
