package ESMS;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.Font;

public class ES {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ES window = new ES();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ES() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.LIGHT_GRAY);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton b1 = new JButton("Staff");
		b1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		b1.setBounds(159, 101, 100, 40);
		frame.getContentPane().add(b1);
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Staff s = new Staff();
					s.staff();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				
			}
		});
		
		JButton b2 = new JButton("User");
		b2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		b2.setBounds(159, 173, 100, 40);
		frame.getContentPane().add(b2);
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					UserLogin u = new UserLogin();
					u.user();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				
			}
		});
		
		JLabel lblNewLabel = new JLabel("ABC ELECTRONICS STORE");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		lblNewLabel.setBounds(48, 23, 358, 43);
		frame.getContentPane().add(lblNewLabel);
	}
}
