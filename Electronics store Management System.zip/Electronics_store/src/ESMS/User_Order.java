package ESMS;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class User_Order{

	private JPanel p1,p2,p3,p;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	private JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	String s;
	JMenu m1;
	private JMenuItem item1;
	
	public User_Order(JPanel p,JFrame frame,String s,JMenuItem item1)
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		this.frame=frame;
		this.p=p;
		this.s=s;
		this.item1=item1;
		l1 = new JLabel("Customer ID");
		l1.setFont(new Font("Verdana", Font.PLAIN, 20));
		l1.setBounds(37, 88, 138, 24);

		
		l2 = new JLabel("Order ID");
		l2.setFont(new Font("Verdana", Font.PLAIN, 20));
		l2.setBounds(57, 154, 97, 24);

		
		l3 = new JLabel("Product ID");
		l3.setFont(new Font("Verdana", Font.PLAIN, 20));
		l3.setBounds(50, 227, 118, 24);

		
		l4 = new JLabel("Product Name");
		l4.setFont(new Font("Verdana", Font.PLAIN, 20));
		l4.setBounds(252, 303, 151, 24);

		
		l5 = new JLabel("Product Type");
		l5.setFont(new Font("Verdana", Font.PLAIN, 20));
		l5.setBounds(265, 375, 138, 24);
		
		l6 = new JLabel("Brand");
		l6.setFont(new Font("Verdana", Font.PLAIN, 20));
		l6.setBounds(297, 452, 69, 24);

		
		l7 = new JLabel("Total Cost");
		l7.setFont(new Font("Verdana", Font.PLAIN, 20));
		l7.setBounds(286, 521, 105, 24);

		
		l8 = new JLabel("Status");
		l8.setFont(new Font("Verdana", Font.PLAIN, 20));
		l8.setBounds(297, 599, 76, 24);

		
		t1 = new JTextField();
		t1.setBounds(215, 93, 151, 24);
		
		t2 = new JTextField();
		t2.setBounds(214, 159, 151, 24);
	
		
		t3 = new JTextField();
		t3.setBounds(214, 227, 151, 24);
		
		
		t4 = new JTextField();
		t4.setBounds(477, 308, 151, 24);
		
		
		t5 = new JTextField();
		t5.setBounds(477, 380, 151, 24);
		
		t6 = new JTextField();
		t6.setBounds(477, 452, 151, 24);
		
		t7 = new JTextField();
		t7.setBounds(477, 526, 151, 24);
		
		t8 = new JTextField();
		t8.setBounds(477, 599, 151, 24);
		
		
		
	}


public void connectToDB() 
{
	try {
	  
	
	Connection con=DriverManager.getConnection(  
	"jdbc:oracle:thin:@localhost:1521:xe","it19737096","vasavi");  
	  
	 
	statement=con.createStatement(); 
	statement.executeUpdate("commit");
	
	
	}
	catch (SQLException connectException) 
	{
	  System.out.println(connectException.getMessage());
	  System.out.println(connectException.getSQLState());
	  System.out.println(connectException.getErrorCode());
	  System.exit(1);
	}
}
private void displaySQLErrors(SQLException e) 
{
	JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	
	
}
public void buildGUI() {
	item1.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			t1.setText(null);
			t2.setText(null);
			t3.setText(null);
			t4.setText(null);
			t5.setText(null);
			t6.setText(null);
			t7.setText(null);
			t8.setText(null);
			
			
			p.removeAll();
			frame.invalidate();
			frame.validate();
			frame.repaint();
			 p1=new JPanel();
			 p1.setLayout(null);
			 p1.add(l1);
			 p1.add(t1);
			 p1.add(l2);
			 p1.add(t2);
			 p1.add(l3);
			 p1.add(t3);
			 p1.add(l4);
			 p1.add(t4);
			 p1.add(l5);
			 p1.add(t5);
			 p1.add(l6);
			 p1.add(t6);
			 p1.add(l7);
			 p1.add(t7);
			 p1.add(l8);
			 p1.add(t8);
			 System.out.println(s);
			 p1.setBackground(new Color(255, 182, 193)) ;
			 p1.setBounds(20,20,800,800);
			 p.add(p1);
			
			 p.setLayout(new BorderLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 t1.setText(s);
				 t1.setEditable(false);
				String query = "select order_id from cust_order where cust_id="+s;
				 try  {
				       rs = statement.executeQuery(query);
				      while (rs.next()) {
				        String oid= rs.getString("order_id");
				        t2.setText(oid);
						 t2.setEditable(false);
						 
				      }}
				    catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				 String query1 = "select totalcost,status from order_details where order_id in (select  order_id from cust_order where cust_id="+s+")";
				 try  {
				       rs = statement.executeQuery(query1);
				      while (rs.next()) {
				    	  String tc= rs.getString("totalcost");
				        String sta= rs.getString("status");
				       
				        t7.setText(tc);
						 t7.setEditable(false);
						 t8.setText(sta);
						 t8.setEditable(false);
				      }}
				    catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				
				 
				 String query2 = "select pid from pick_product where cust_id="+s;
				 try  {
				       rs = statement.executeQuery(query2);
				      while (rs.next()) {
				        String pid= rs.getString("pid");
				        t3.setText(pid);
						 t3.setEditable(false);
						 
				      }}
				    catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				 String query3 = "select pname,type from product where pid in (select  pid from pick_product where cust_id="+s+")";
				 try  {
				       rs = statement.executeQuery(query3);
				      while (rs.next()) {
				    	  String pname= rs.getString("pname");
				        String type= rs.getString("type");
				       
				        t4.setText(pname);
						 t4.setEditable(false);
						 t5.setText(type);
						 t5.setEditable(false);
				      }}
				    catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				 String query4 = "select bname from brand where bid in (select bid from manage_stock where pid in(select pid from pick_product where cust_id="+s+"))";
				 try  {
				       rs = statement.executeQuery(query4);
				      while (rs.next()) {
				        String bname= rs.getString("bname");
				        t6.setText(bname);
						 t6.setEditable(false);
						 
				      }}
				    catch (SQLException e) {
				    	displaySQLErrors(e);
				    }
				 
				
				 
				 
		}
	});
}}
