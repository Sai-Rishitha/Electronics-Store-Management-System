package ESMS;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import java.awt.Color;
import javax.swing.JMenu;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ESUser extends JFrame {

	JMenuBar menu;
	//private JFrame frame;
	private JMenu m1,m2,m3;
	JLabel label;
	JPanel pan1, pan2;
	String s;
	JLabel lblNewLabel;
	JMenuItem mi1,mi2,mi3;
	
	void initialize()
	{
		menu = new JMenuBar();
		m1 = new JMenu("Account Details");
		m3 = new JMenu("Order Details");
		pan1=new JPanel();
		pan2=new JPanel();
		mi1 = new JMenuItem("View Details");
		mi3 = new JMenuItem("Check Order");
	}
	void addComponents()
	{
		m1.add(mi1);
		m3.add(mi3);
		m1.setForeground(new Color(128, 0, 128));		m3.setForeground(new Color(128, 0, 128));
		menu.add(m1);
		menu.add(m3);
		 setJMenuBar(menu);
		 lblNewLabel = new JLabel("WELCOME TO ABC ELECTRONICS STORE!");
		 pan1.add(lblNewLabel);
		 lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 38));
		 lblNewLabel.setBounds(27, 102, 831, 106);
		 pan2.setAlignmentY(CENTER_ALIGNMENT);
		 pan2.setBackground(new Color(255, 182, 193));
		 pan2.setBounds(200,600,200,200);	
		 pan1.add(pan2);
		 pan1.setBackground(new Color(255, 182, 193));
		 getContentPane().add(pan1);
	}
	void closeWindow()
	{
		try 
		{
			JOptionPane.showMessageDialog(this,"Thank you for shopping with us!","Quit",JOptionPane.WARNING_MESSAGE);
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
	void register(String s)
	{
		System.out.println(s);
		User_Details u = new User_Details(pan1,ESUser.this,s,mi1);
		u.buildGUI();
		User_Order uo = new User_Order(pan1,ESUser.this,s,mi3);
		uo.buildGUI();
		
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
	}
	public ESUser(String s) {
		this.s=s;
		initialize();
		addComponents();
	    register(s);
		//pack();
		setTitle("ABC Electronics Store");
		setSize(900,820);
		setVisible(true);
	}
}
	
	
   
		
		
		
		
		
		
		
		
		
		
		
		
	