package ESMS;
import java.awt.Color;


import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import ESMS.OrderDetails;
import ESMS.Customer_Login;
import ESMS.Esms;
import ESMS.Cust_account;

public class Esms extends JFrame {
 
	 //private static final long serialVersionUID = 1L;
	 
	 JMenuBar menu;
	
     private JMenu login;
     private JMenu customer_login;
 	 private JMenu cust_account;
 	 private JMenu cust_order;
 	 private JMenu order_details;
 	 private JMenu orders_from;
 	 private JMenu brand;
 	 private JMenu select;
 	 private JMenu product;
	
	 JMenuItem insert1,update1,delete1,view1;
	 JMenuItem insert2,update2,delete2,view2;
	 JMenuItem insert3,update3,delete3,view3;
	 JMenuItem insert4,update4,delete4,view4;
	 JMenuItem insert5,update5,delete5,view5;
	 JMenuItem insert6,update6,delete6,view6;
	 JMenuItem insert7,update7,delete7,view7;
	 JMenuItem insert8,update8,delete8,view8;
	 JMenuItem insert9,update9,delete9,view9;
	 
	 JLabel label;
	
	 JPanel pan1, pan2;
	 


	void initialize()
	{
		menu = new JMenuBar();
		login = new JMenu("Login");
		customer_login = new JMenu("Add Customer");
		cust_account = new JMenu("Cust Details");
		cust_order = new JMenu("Cust Order");
		order_details = new JMenu("Order Details");
		orders_from = new JMenu("Manage Stock");
		brand = new JMenu("Brand");
		select = new JMenu("Pick Product");
		product = new JMenu("Product");
		
		
		label=new JLabel("Welcome to ABC Electronics Store!");
		label.setFont(new Font("Verdana",Font.BOLD,20));
		label.setPreferredSize(new Dimension(400,80));
		label.setForeground(Color.WHITE);
		pan1=new JPanel();
		pan2=new JPanel();
		insert1 = new JMenuItem("Submit");
		update1 = new JMenuItem("Modify");
		delete1 = new JMenuItem("Delete");
		view1 = new JMenuItem("View");
		insert2 = new JMenuItem("Submit");
		update2 = new JMenuItem("Modify");
		delete2 = new JMenuItem("Delete");
		view2 = new JMenuItem("View");
		insert3 = new JMenuItem("Submit");
		update3 = new JMenuItem("Modify");
		delete3 = new JMenuItem("Delete");
		view3 = new JMenuItem("View");
		insert4 = new JMenuItem("Submit");
		update4 = new JMenuItem("Modify");
		delete4 = new JMenuItem("Delete");
		view4 = new JMenuItem("View");
		insert5 = new JMenuItem("Submit");
		update5 = new JMenuItem("Modify");
		delete5 = new JMenuItem("Delete");
		view5 = new JMenuItem("View");
		insert6 = new JMenuItem("Submit");
		update6 = new JMenuItem("Modify");
		delete6 = new JMenuItem("Delete");
		view6 = new JMenuItem("View");
		insert7 = new JMenuItem("Submit");
		update7 = new JMenuItem("Modify");
		delete7 = new JMenuItem("Delete");
		view7 = new JMenuItem("View");
		insert8 = new JMenuItem("Submit");
		update8 = new JMenuItem("Modify");
		delete8 = new JMenuItem("Delete");
		view8 = new JMenuItem("View");
		insert9 = new JMenuItem("Submit");
		update9 = new JMenuItem("Modify");
		delete9 = new JMenuItem("Delete");
		view9 = new JMenuItem("View");
	}
	void addComponents()
	{
		 //login.add(insert1);
	     login.add(update1);
		 login.add(delete1);
		 login.add(view1);
		 customer_login.add(insert2);
		 customer_login.add(update2);
		 customer_login.add(delete2);
		 customer_login.add(view2);
		 cust_account.add(insert3);
		 cust_account.add(update3);
		 cust_account.add(delete3);
		 cust_account.add(view3);
		 cust_order.add(insert4);
		 cust_order.add(update4);
		 cust_order.add(delete4);
		 cust_order.add(view4);
		 order_details.add(insert5);
		 order_details.add(update5);
		 order_details.add(delete5);
		 order_details.add(view5);
		 orders_from.add(insert6);
		 orders_from.add(update6);
		 orders_from.add(delete6);
		 orders_from.add(view6);
		 brand.add(insert7);
	     brand.add(update7);
		 brand.add(delete7);
		 brand.add(view7);
		 select.add(insert8);
	     select.add(update8);
		 select.add(delete8);
		 select.add(view8);
		 product.add(insert9);
	     product.add(update9);
		 product.add(delete9);
		 product.add(view9);
		 login.setOpaque(true);
		 login.setBackground(Color.BLUE);
		 login.setForeground(Color.WHITE);
		 cust_account.setOpaque(true);
		 cust_account.setBackground(Color.MAGENTA);
		 cust_account.setForeground(Color.BLACK);
		 customer_login.setOpaque(true);
		 customer_login.setBackground(Color.BLUE);
		 customer_login.setForeground(Color.WHITE);
		 brand.setOpaque(true);
		 brand.setBackground(Color.MAGENTA);
		 brand.setForeground(Color.BLACK);
		 orders_from.setOpaque(true);
		 orders_from.setBackground(Color.BLUE);
		 orders_from.setForeground(Color.WHITE);
		 product.setOpaque(true);
		 product.setBackground(Color.MAGENTA);
		 product.setForeground(Color.BLACK);
		 select.setOpaque(true);
		 select.setBackground(Color.BLUE);
		 select.setForeground(Color.WHITE);
		 order_details.setOpaque(true);
		 order_details.setBackground(Color.MAGENTA);
		 order_details.setForeground(Color.BLACK);
		 cust_order.setOpaque(true);
		 cust_order.setBackground(Color.BLUE);
		 cust_order.setForeground(Color.WHITE);
		 menu.add(login);
		 menu.add(cust_account);
		 menu.add(customer_login);
		 menu.add(brand);
		 menu.add(orders_from);
		 menu.add(product);
		 menu.add(select);
		 menu.add(order_details);
		 menu.add(cust_order);
		
		 
		 
		 setJMenuBar(menu); 
		//menu.add(login);
		 //menu.add(cust_account);
		 pan2.add(label);
		 pan2.setAlignmentY(CENTER_ALIGNMENT);
		 pan2.setBackground(Color.GRAY);
		 pan2.setBounds(200,600,200,200);	
		 pan1.add(pan2);
		 pan1.setBackground(Color.PINK);
		 add(pan1);
		/* ImageIcon im=new ImageIcon("image.jpg");
		 JLabel iml=new JLabel(im);
		 iml.setBounds(10,10,400,400);
		 iml.setVisible(true);
		 add(iml);*/
	}
	
	void closeWindow()
	{
		try 
		{
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to exit ABC ELECTRONICS STORE?");
			if(a==JOptionPane.YES_OPTION)
			{  
				//JOptionPane.showMessageDialog(this,"Thank you for shopping with us!","Quit",JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) 
			{
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) 
			{
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}

   void register() {
		Login log=new Login(pan1,Esms.this,insert1,delete1,update1,view1);
		log.buildGUI();
		Cust_account user=new Cust_account(pan1,Esms.this,insert3,delete3,update3,view3); 
		user.buildGUI();
		Customer_Login log_user=new Customer_Login(pan1,Esms.this,insert2,delete2,update2,view2); 
		log_user.buildGUI();
		OrderDetails orders=new OrderDetails(pan1,Esms.this,insert5,delete5,update5,view5); 
		orders.buildGUI();
		Customer_Order co = new Customer_Order(pan1,Esms.this,insert4,delete4,update4,view4);
		co.buildGUI();
		Brand b= new Brand(pan1,Esms.this,insert7,delete7,update7,view7);
		b.buildGUI();
		Product p = new Product(pan1,Esms.this,insert9,delete9,update9,view9);
		p.buildGUI();
		Manage_Stock of = new Manage_Stock(pan1,Esms.this,insert6,delete6,update6,view6);
		of.buildGUI();
        Pick_Product s = new Pick_Product(pan1,Esms.this,insert8,delete8,update8,view8);
		s.buildGUI();
		//Manage_Stock m = new Manage_Stock(pan1,Esms.this,insert8,delete8,update8,view8);
		//m.buildGUI();
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
		
	}
	
	public Esms() {
		initialize();
		addComponents();
	    register();
		//pack();
		setTitle("ABC Electronics Store");
		setSize(900,820);
		setVisible(true);
	}
}
	

