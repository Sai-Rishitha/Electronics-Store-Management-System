package ESMS;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class UserLogin {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	Statement statement;
	Connection con;ResultSet rs;
	public void user() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogin window = new UserLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737096","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	public UserLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 10));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("ABC ELECTRONICS STORE");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		lblNewLabel.setBounds(35, 23, 370, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User Login");
		lblNewLabel_1.setFont(new Font("Verdana", Font.BOLD, 17));
		lblNewLabel_1.setBounds(150, 65, 108, 34);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(234, 120, 96, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(234, 168, 96, 26);
		frame.getContentPane().add(passwordField);
		
		JLabel lblNewLabel_2 = new JLabel("Customer ID");
		lblNewLabel_2.setFont(new Font("Verdana", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(65, 120, 114, 26);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setFont(new Font("Verdana", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(73, 168, 80, 20);
		frame.getContentPane().add(lblNewLabel_3);
		
		JButton b1 = new JButton("Login");
	//	b1= new JButton("Login");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean isValidUser=false;
				try {
					connectToDB();
					//Connection con = connect.getConnection();
				//	Statement stmt=con.createStatement();
					String txt = "select cust_id,password from cust_account where cust_id = '"+textField.getText()+"' and password ='"+new String(passwordField.getPassword())+"'";
					//System.out.println(txt);
					rs=statement.executeQuery(txt);
					if(rs.next()) {
						isValidUser = true;
					}
					rs.close();
					
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
				if(isValidUser) {
					//JOptionPane.showMessageDialog(null,"Valid User");
					ESUser h=new ESUser(textField.getText());
					//login code here
				}
				else {
					JOptionPane.showMessageDialog(null,"Invalid User");
				}
				
			}
		});
		b1.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		b1.setBounds(159, 218, 85, 21);
		frame.getContentPane().add(b1);
	}
}
